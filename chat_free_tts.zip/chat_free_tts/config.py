# Голоса
voices_list = [
    ("ru-RU-SvetlanaNeural", "ru Светлана"),
    ("en-US-EmmaMultilingualNeural", "us Emma"),
    ("en-US-BrianMultilingualNeural", "us Brian"),
    ("ru-RU-DmitryNeural", "ru Дмитрий"),
    ("ru-RU-DariyaNeural", "ru Дария"),
    ("uz-UZ-SardorNeural", "uz Сардор"),
    ("uz-UZ-MadinaNeural", "uz Мадина")
]
voice_index = 0

# Настройки TTS
speech_speed = 0
speech_volume = 0
use_offline = False
MAX_INPUT_LEN = 500

# Цвета Pygame
WHITE, BLACK, GRAY, BLUE, RED, GREEN = (255,)*3, (0,)*3, (240,)*3, (0,0,255), (255,0,0), (0,200,0)

# Pygame параметры
WIDTH, HEIGHT = 800, 600
