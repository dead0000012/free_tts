import pygame as pg
from chat_utils import wrap_text
from settings import config, ui
import internet_check


def render_ui(WIDTH, HEIGHT, screen, font, chat, input_text, scroll_offset,
              scroll_speed, scrolling_up, scrolling_down, dark_mode,
              volume_drag, playback_ctrl):
    """Render the entire UI. Parameters are passed from the main loop so this
    function doesn't rely on global state in main.py and can live in its own
    module.
    """
    screen.fill(config.WHITE)
    if dark_mode:
        bg_color = (30, 30, 30)
        panel_color = (60, 60, 60)
        text_color = (200, 200, 200)
        phone_color = (25,25,25)
        red = (200, 0, 0)
        white = (35, 35, 35)
    else:
        bg_color = config.WHITE
        panel_color = (40, 40, 40)
        text_color = config.BLACK
        phone_color = config.GRAY
        red = (200, 0, 0)
        white = (250, 250, 250)

    screen.fill(bg_color)
    back_block = pg.Rect(20, 20, WIDTH - 40, HEIGHT - 210)
    back = pg.draw.rect(screen, phone_color, back_block, border_radius=7 )
    input_1 = pg.draw.rect(screen, phone_color, (20, HEIGHT - 100, WIDTH - 40, 80), border_radius=7 )
    stop_play = pg.draw.circle(screen, red, (ui.STOP_PLAY_CX, HEIGHT - ui.STOP_PLAY_CY_OFFSET), ui.STOP_PLAY_R)
    # draw stop/play/pause icon according to controller state
    cx, cy = ui.STOP_PLAY_CX, HEIGHT - ui.STOP_PLAY_CY_OFFSET
    is_playing = playback_ctrl.is_playing()
    is_paused = playback_ctrl.is_paused()
    has_content = playback_ctrl.has_content()
    if is_playing:
        # playing -> show pause bars
        bar_w, bar_h = 4, 17
        pg.draw.rect(screen, white, (cx - 7, cy - bar_h//2, bar_w, bar_h))
        pg.draw.rect(screen, white, (cx + 3, cy - bar_h//2, bar_w, bar_h))
    elif is_paused:
        pts = [(cx - 6, cy - 8), (cx + 8, cy), (cx - 6, cy + 8)]
        pg.draw.polygon(screen, white, pts)
    else:
        pts = [(cx - 6, cy - 8), (cx + 8, cy), (cx - 6, cy + 8)]
        disabled_color = (150, 150, 150) if not dark_mode else (80,80,80)
        pg.draw.polygon(screen, disabled_color, pts)

    infspeed = pg.draw.circle(screen, red, (115, HEIGHT - 130), 25)
    # load/progress area
    back_load = pg.draw.rect(screen, phone_color, (20, HEIGHT - 185, WIDTH - 40, 23), 2, border_radius=3)

    # speed control visuals
    speed = pg.Rect(155, HEIGHT - 152, 45, 45)
    speed_1 = pg.draw.rect(screen, red, speed , border_radius=3)
    speed_center = (speed.x + speed.width//2, speed.y + speed.height//2)
    chev_w = 12
    chev_h = 8
    up = [
        (speed_center[0] - chev_w//2, speed_center[1] + 2),
        (speed_center[0], speed_center[1] - chev_h),
        (speed_center[0] + chev_w//2, speed_center[1] + 2),
    ]
    down = [
        (speed_center[0] - chev_w//2, speed_center[1] + chev_h + 4),
        (speed_center[0], speed_center[1] + 2),
        (speed_center[0] + chev_w//2, speed_center[1] + chev_h + 4),
    ]
    pg.draw.polygon(screen, white, up)
    pg.draw.polygon(screen, white, down)

    # progress bar area
    prog_x, prog_y = 22, HEIGHT - 183
    prog_w, prog_h = WIDTH - 44, 19
    pg.draw.rect(screen, phone_color, (prog_x, prog_y, prog_w, prog_h), border_radius=3)
    elapsed, duration = playback_ctrl.get_playback_progress()
    if duration is not None and duration > 0:
        frac = max(0.0, min(1.0, elapsed / duration))
        fill_w = int(frac * prog_w)
        if fill_w > 0:
            pg.draw.rect(screen, red, (prog_x, prog_y, fill_w, prog_h), border_radius=3)
    elif playback_ctrl.has_content():
        t = pg.time.get_ticks() / 1000.0
        wave = int((t * 100) % prog_w)
        ind_w = max(30, prog_w // 6)
        pg.draw.rect(screen, config.GREEN, (prog_x + wave, prog_y, ind_w, prog_h), border_radius=3)

    # volume slider
    slider_x = ui.SLIDER_X
    slider_y = HEIGHT - ui.SLIDER_Y_OFFSET
    slider_w = max(40, WIDTH - ui.SLIDER_W_MARGIN)
    slider_h = ui.SLIDER_H
    slider_rect = pg.Rect(slider_x, slider_y, slider_w, slider_h)
    pg.draw.rect(screen, phone_color, slider_rect, border_radius=3)
    vol_percent = playback_ctrl.get_volume_percent()
    fill_w = int(((vol_percent + 100) / 200.0) * slider_w)
    if fill_w > 0:
        pg.draw.rect(screen, red, (slider_x, slider_y, fill_w, slider_h), border_radius=3)
    thumb_x = slider_x + fill_w
    thumb_y = slider_y + slider_h // 2
    pg.draw.circle(screen, (220,220,220), (thumb_x, thumb_y), 6)

    # mute button
    volume_mute = pg.Rect(215, HEIGHT - 152, 45, 45)
    is_muted = getattr(playback_ctrl, '_is_muted', False)
    mute_color = (120, 120, 120) if is_muted else red
    pg.draw.rect(screen, mute_color, volume_mute , border_radius=3)

    # settings button
    settings_btn = pg.draw.circle(screen, red, (WIDTH - 50, HEIGHT - 130), 25)

    # render chat lines
    line_height = 23
    max_lines_visible = (HEIGHT - 220) // line_height
    all_lines = []
    for speaker, message in chat:
        color = config.BLUE if speaker != 'Ты' else text_color
        wrapped_lines = wrap_text(f"{speaker}: {message}", font, WIDTH - 60)
        for l in wrapped_lines:
            all_lines.append((l, color))
    start_index = max(0, len(all_lines) - max_lines_visible - scroll_offset)
    end_index = len(all_lines) - scroll_offset if scroll_offset != 0 else None
    visible_lines = all_lines[start_index:end_index]
    y = 30
    for line, color in visible_lines:
        surf = font.render(line, True, color)
        screen.blit(surf, (30, y))
        y += line_height

    # input area
    input_surf = font.render(input_text, True, text_color)
    screen.blit(input_surf, (30, HEIGHT - 90))
    circle_color = config.GREEN if (not config.use_offline and internet_check.internet_status) else config.RED
    pg.draw.circle(screen, circle_color, (20, 10), 6)
