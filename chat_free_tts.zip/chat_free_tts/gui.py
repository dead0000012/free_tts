import pygame as pg
import math

from chat_utils import wrap_text
from settings import config, ui
import internet_check
from playback_controller import playback_ctrl


def render_ui(screen, WIDTH, HEIGHT, font, chat, input_text, scroll_offset,
              current_speed, dark_mode, show_settings, music_paused):
    """Draw the entire UI and return a dict of interactive targets used by the
    main loop for hit-testing. Keys returned:
      - play_circle: (x, y, r)
      - infspeed_circle: (x, y, r)
      - speed_rect: pygame.Rect
      - volume_mute: pygame.Rect
      - slider_rect: pygame.Rect
      - settings_btn: pygame.Rect (from draw)
      - settings_panel_rect: pygame.Rect or None
      - repeat_rect: pygame.Rect or None
      - voice_item_rects: list of pygame.Rect
      - upload_rect: pygame.Rect or None
    """
    # colors and theme
    if dark_mode:
        bg_color = (30, 30, 30)
        panel_color = (60, 60, 60)
        text_color = (200, 200, 200)
        phone_color = (25, 25, 25)
        button_color = (70, 157, 140)
        white = (35, 35, 35)
    else:
        bg_color = config.WHITE
        panel_color = (40, 40, 40)
        text_color = config.BLACK
        phone_color = config.GRAY
        button_color = (88, 210, 185)
        white = (250, 250, 250)

    screen.fill(bg_color)
    # when settings panel is open, shrink main back_block width to make room on the right
    main_panel_width = WIDTH - 40 if not show_settings else max(200, WIDTH - 300)
    back_block = pg.Rect(20, 20, main_panel_width, HEIGHT - 210)
    pg.draw.rect(screen, phone_color, back_block, border_radius=7)

    # input area and play controls
    pg.draw.rect(screen, phone_color, (20, HEIGHT - 100, WIDTH - 40, 80), border_radius=7)
    cx, cy = 50, HEIGHT - 130
    is_playing = playback_ctrl.is_playing()
    is_paused = playback_ctrl.is_paused()
    pg.draw.circle(screen, button_color, (cx, cy), 25)
    if is_playing:
        bar_w, bar_h = 3, 17
        pg.draw.rect(screen, white, (cx - 7, cy - bar_h // 2, bar_w, bar_h))
        pg.draw.rect(screen, white, (cx + 3, cy - bar_h // 2, bar_w, bar_h))
    elif is_paused:
        pts = [(cx - 6, cy - 8), (cx + 8, cy), (cx - 6, cy + 8)]
        pg.draw.polygon(screen, white, pts)
    else:
        pts = [(cx - 6, cy - 8), (cx + 8, cy), (cx - 6, cy + 8)]
        disabled_color = (150, 150, 150) if not dark_mode else (80, 80, 80)
        pg.draw.polygon(screen, disabled_color, pts)

    # small infspeed circle
    inf_x, inf_y, inf_r = 115, HEIGHT - 130, 25
    pg.draw.circle(screen, button_color, (inf_x, inf_y), inf_r)
    try:
        pg.draw.arc(screen, white, (100, HEIGHT - 145, 30, 30), math.radians(190), math.radians(497), 2)
    except Exception:
        pass
    pg.draw.polygon(screen, white, [(102, HEIGHT - 134), (101, HEIGHT - 141), (108, HEIGHT - 140), (112, HEIGHT - 138)])

    # bottom controls: speed, volume, progress
    speed_rect = pg.Rect(155, HEIGHT - 152, 45, 45)
    pg.draw.rect(screen, button_color, speed_rect, border_radius=3)
    speed_text = font.render(f"{current_speed}x", True, white)
    screen.blit(speed_text, (165, HEIGHT - 140))

    volume_mute = pg.Rect(215, HEIGHT - 152, 45, 45)
    is_muted = getattr(playback_ctrl, '_is_muted', False)
    pg.draw.rect(screen, (100, 100, 100), volume_mute, 2)

    x, y, w, h = volume_mute
    speaker_mute = [
        (x + 6, y + h // 3),
        (x + 14, y + h // 3),
        (x + 22, y + 10),
        (x + 22, y + h - 10),
        (x + 14, y + 2 * h // 3),
        (x + 6, y + 2 * h // 3),
    ]
    center = (x + 25, y + h // 2)
    cx2 = x + w - 13
    cy2 = y + h // 2
    size = 5
    mute_color = (120, 120, 120) if is_muted else button_color
    pg.draw.rect(screen, mute_color, volume_mute, border_radius=3)
    pg.draw.polygon(screen, white, speaker_mute)
    if is_muted:
        pg.draw.line(screen, white, (cx2 - size, cy2 - size), (cx2 + size, cy2 + size), 3)
        pg.draw.line(screen, white, (cx2 - size, cy2 + size), (cx2 + size, cy2 - size), 3)
    else:
        for radius in [6, 10, 14]:
            rect = pg.Rect(center[0] - radius, center[1] - radius, radius * 2, radius * 2)
            pg.draw.arc(screen, white, rect, math.radians(-55), math.radians(55), 1)

    # interactive volume slider
    slider_x = ui.SLIDER_X
    slider_y = HEIGHT - ui.SLIDER_Y_OFFSET
    slider_w = max(40, WIDTH - ui.SLIDER_W_MARGIN)
    slider_h = ui.SLIDER_H
    slider_rect = pg.Rect(slider_x, slider_y, slider_w, slider_h)
    pg.draw.rect(screen, phone_color, slider_rect, border_radius=3)
    vol_percent = playback_ctrl.get_volume_percent()
    fill_w = int(((vol_percent + 100) / 200.0) * slider_w)
    if fill_w > 0:
        pg.draw.rect(screen, button_color, (slider_x, slider_y, fill_w, slider_h), border_radius=3)
    thumb_x = slider_x + fill_w
    thumb_y = slider_y + slider_h // 2
    pg.draw.circle(screen, (220, 220, 220), (thumb_x, thumb_y), 6)

    # playback progress
    prog_x, prog_y = 22, HEIGHT - 183
    prog_w, prog_h = WIDTH - 44, 19
    pg.draw.rect(screen, phone_color, (prog_x, prog_y, prog_w, prog_h), border_radius=3)
    elapsed, duration = playback_ctrl.get_playback_progress()
    if duration is not None and duration > 0:
        frac = max(0.0, min(1.0, elapsed / duration))
        fill_w2 = int(frac * prog_w)
        if fill_w2 > 0:
            pg.draw.rect(screen, button_color, (prog_x, prog_y, fill_w2, prog_h), border_radius=3)
    elif playback_ctrl.has_content():
        t = pg.time.get_ticks() / 1000.0
        wave = int((t * 100) % prog_w)
        ind_w = max(30, prog_w // 6)
        pg.draw.rect(screen, config.GREEN, (prog_x + wave, prog_y, ind_w, prog_h), border_radius=3)

    # settings button / gear icon
    center_btn = (WIDTH - 50, HEIGHT - 130)
    radius = 18
    settings_btn = pg.draw.circle(screen, button_color, center_btn, 25)
    if settings_btn.collidepoint(pg.mouse.get_pos()):
        pg.draw.circle(screen, phone_color, center_btn, 25)
    hexagon = [
        (center_btn[0] + radius * math.cos(math.radians(a)), center_btn[1] + radius * math.sin(math.radians(a)))
        for a in range(30, 390, 60)
    ]
    pg.draw.circle(screen, white, center_btn, 9, 2)
    pg.draw.polygon(screen, white, hexagon, 3)

    # prepare return targets
    targets = {
        'play_circle': (cx, cy, 25),
        'infspeed_circle': (inf_x, inf_y, inf_r),
        'speed_rect': speed_rect,
        'volume_mute': volume_mute,
        'slider_rect': slider_rect,
        'settings_btn': settings_btn,
        'settings_panel_rect': None,
        'repeat_rect': None,
        'voice_item_rects': [],
        'upload_rect': None,
    }

    # settings right-side panel (with Repeat toggle, voices list and Upload)
    if show_settings:
        right_w = 240
        final_x = WIDTH - right_w - 20
        right_rect = pg.Rect(final_x, 20, right_w, HEIGHT - 210)
        pg.draw.rect(screen, panel_color, right_rect, border_radius=6)
        hdr = font.render("Voices:", True, text_color)
        screen.blit(hdr, (final_x + 12, 24))

        repeat_y = 24 + 30
        repeat_h = 34
        repeat_rect = pg.Rect(final_x + 12, repeat_y, right_w - 24, repeat_h)
        repeat_on = getattr(playback_ctrl, '_repeat', False)
        repeat_color = (0, 180, 0) if repeat_on else (120, 120, 120)
        pg.draw.rect(screen, repeat_color, repeat_rect, border_radius=6)
        rep_txt = font.render("Repeat", True, white)
        screen.blit(rep_txt, (repeat_rect.x + 8, repeat_rect.y + (repeat_h - rep_txt.get_height()) // 2))

        item_y = repeat_y + repeat_h + 8
        item_h = 28
        pad_x = 10
        voice_item_rects = []
        for i, v in enumerate(config.voices_list):
            v_name = v[1] if len(v) > 1 else str(v[0])
            item_rect = pg.Rect(final_x + pad_x, item_y, right_w - pad_x * 2, item_h)
            if i == getattr(config, 'voice_index', 0):
                pg.draw.rect(screen, (80, 80, 140), item_rect, border_radius=4)
                txt_color = white
            else:
                txt_color = text_color
            txt = font.render(v_name, True, txt_color)
            screen.blit(txt, (item_rect.x + 6, item_y + 4))
            voice_item_rects.append(item_rect)
            item_y += item_h + 6

        # upload button near bottom of panel
        up_h = 34
        up_w = right_w - 24
        up_x = final_x + 12
        up_y = right_rect.bottom - up_h - 12
        upload_rect = pg.Rect(up_x, up_y, up_w, up_h)
        pg.draw.rect(screen, (100, 100, 240), upload_rect, border_radius=6)
        up_txt = font.render("Upload", True, white)
        screen.blit(up_txt, (upload_rect.x + 8, upload_rect.y + (up_h - up_txt.get_height()) // 2))

        targets['settings_panel_rect'] = right_rect
        targets['repeat_rect'] = repeat_rect
        targets['voice_item_rects'] = voice_item_rects
        targets['upload_rect'] = upload_rect

    # render chat lines
    line_height = 23
    max_lines_visible = (HEIGHT - 220) // line_height
    all_lines = []
    for speaker, message in chat:
        color = config.BLUE if speaker != 'Ты' else text_color
        wrapped_lines = wrap_text(f"{speaker}: {message}", font, WIDTH - 60)
        for l in wrapped_lines:
            all_lines.append((l, color))

    start_index = max(0, len(all_lines) - max_lines_visible - scroll_offset)
    end_index = len(all_lines) - scroll_offset if scroll_offset != 0 else None
    visible_lines = all_lines[start_index:end_index]

    y = 30
    for line, color in visible_lines:
        surf = font.render(line, True, color)
        screen.blit(surf, (30, y))
        y += line_height

    input_surf = font.render(input_text, True, text_color)
    screen.blit(input_surf, (30, HEIGHT - 90))
    circle_color = config.GREEN if (not config.use_offline and internet_check.internet_status) else config.RED
    pg.draw.circle(screen, circle_color, (20, 10), 6)

    return targets
