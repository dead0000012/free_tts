import pygame as pg
import pyperclip
from chat_utils import wrap_text
from settings import config
from settings import ui
from speech import speak_async_chunked
import internet_check
from playback_controller import playback_ctrl
import math
import os
from gui import render_ui

# --- Pygame init ---
pg.init()
try:
    pg.mixer.init()
except Exception:
    print("Warning: pygame.mixer init failed; audio may not work.")
WIDTH, HEIGHT = ui.WIDTH, ui.HEIGHT
screen = pg.display.set_mode((WIDTH, HEIGHT), pg.RESIZABLE)
pg.display.set_caption("Free TTS Chat")
font = pg.font.SysFont("Chicoree Em", 28)
clock = pg.time.Clock()

chat = []
input_text = ''
scroll_offset = 0
scroll_speed = 1
scrolling_up = scrolling_down = False
dark_mode = False
show_settings = False
music_paused = False

# steps and bounds
SPEED_STEP = ui.SPEED_STEP
VOLUME_STEP = ui.VOLUME_STEP
MIN_SPEED, MAX_SPEED = ui.MIN_SPEED, ui.MAX_SPEED
MIN_VOLUME, MAX_VOLUME = ui.MIN_VOLUME, ui.MAX_VOLUME

volume_drag = False
# persistent current speed multiplier (1..4). Initialize from shared config (stored as percent, 50 == 1x)
current_speed = max(1, min(4, int(round(getattr(config, 'speech_speed', 50) / 50))))

# authoritative targets from last frame (filled by render_ui)
last_targets = {}

# --- Главный цикл ---
running = True
while running:
    for e in pg.event.get():
        # latest interactive targets provided by the last render
        targets = last_targets
        if e.type == pg.QUIT or (e.type == pg.KEYDOWN and e.key == pg.K_ESCAPE):
            running = False
        elif e.type == pg.VIDEORESIZE:
            WIDTH, HEIGHT = e.w, e.h
            screen = pg.display.set_mode((WIDTH, HEIGHT), pg.RESIZABLE)
        elif e.type == pg.MOUSEBUTTONDOWN:
            mx, my = e.pos
            # left click on stop_play circle toggles pause/unpause via controller
            if e.button == 1:
                # stop/play area (use target from renderer)
                play_circle = targets.get('play_circle')
                if play_circle:
                    px, py, pr = play_circle
                    if (mx - px) ** 2 + (my - py) ** 2 <= pr ** 2:
                        # Only allow interactions when there is content (playing or queued)
                        if playback_ctrl.has_content():
                            # if currently playing -> toggle pause; otherwise start/resume
                            if playback_ctrl.is_playing():
                                playback_ctrl.toggle_pause()
                            else:
                                playback_ctrl.resume_or_start()
                # click on volume slider -> begin drag
                # slider
                slider_rect = targets.get('slider_rect')
                if slider_rect and slider_rect.collidepoint(mx, my):
                    volume_drag = True
                    rel = (mx - slider_rect.x) / slider_rect.w
                    new_percent = int(rel * 200 - 100)
                    new_percent = max(MIN_VOLUME, min(MAX_VOLUME, new_percent))
                    playback_ctrl.set_volume(new_percent)
                    config.speech_volume = new_percent
                # infspeed circle (pause/unpause mixer)
                inf = targets.get('infspeed_circle')
                if inf:
                    ix, iy, ir = inf
                    if (mx - ix) ** 2 + (my - iy) ** 2 <= ir ** 2:
                        # toggle mixer pause state
                        try:
                            if not music_paused:
                                pg.mixer.music.pause()
                                music_paused = True
                            else:
                                pg.mixer.music.unpause()
                                music_paused = False
                        except Exception:
                            # ignore mixer errors
                            pass
                # click on mute rectangle -> toggle mute
                mute_rect = targets.get('volume_mute')
                if mute_rect and mute_rect.collidepoint(mx, my):
                    playback_ctrl.toggle_mute()
                # click on speed
                speed_rect_click = targets.get('speed_rect')
                if speed_rect_click and speed_rect_click.collidepoint(mx, my):
                    current_speed = (current_speed % 4) + 1
                    config.speech_speed = current_speed * 50
                # settings button -> toggle
                settings_btn_rect = targets.get('settings_btn')
                if settings_btn_rect and settings_btn_rect.collidepoint(mx, my):
                    show_settings = not show_settings
                # settings panel items
                if show_settings:
                    # upload
                    upload_rect = targets.get('upload_rect')
                    if upload_rect and upload_rect.collidepoint(mx, my):
                        try:
                            import tkinter as tk
                            from tkinter import filedialog
                            root = tk.Tk()
                            root.withdraw()
                            path = filedialog.askopenfilename(title='Select TTS file')
                            root.destroy()
                        except Exception:
                            path = None
                        if path:
                            name = os.path.basename(path)
                            config.voices_list.append((path, name))
                            config.voice_index = len(config.voices_list) - 1
                    # voice items
                    for i, rect in enumerate(targets.get('voice_item_rects', [])):
                        if rect.collidepoint(mx, my):
                            config.voice_index = i
                            break
                    # repeat button
                    repeat_rect = targets.get('repeat_rect')
                    if repeat_rect and repeat_rect.collidepoint(mx, my):
                        playback_ctrl.toggle_repeat()
            elif e.button == 3:
                # right-click on stop_play -> stop and clear queue
                cx, cy, r = 50, HEIGHT - 130, 25
                if (mx - cx) ** 2 + (my - cy) ** 2 <= r ** 2:
                    playback_ctrl.stop()

        elif e.type == pg.MOUSEBUTTONUP:
            if e.button == 1:
                volume_drag = False

        elif e.type == pg.MOUSEMOTION:
            mx, my = e.pos
            if volume_drag:
                slider_rect = targets.get('slider_rect') or pg.Rect(270, HEIGHT - 137, max(40, WIDTH - 370), 15)
                rel = (mx - slider_rect.x) / slider_rect.w
                rel = max(0.0, min(1.0, rel))
                new_percent = int(rel * 200 - 100)
                new_percent = max(MIN_VOLUME, min(MAX_VOLUME, new_percent))
                playback_ctrl.set_volume(new_percent)
                config.speech_volume = new_percent
                # if volume adjusted while muted, unmute automatically
                if getattr(playback_ctrl, '_is_muted', False):
                    playback_ctrl.unmute()

        elif e.type == pg.KEYDOWN:
            mods = pg.key.get_mods()
            if e.key == pg.K_BACKSPACE:
                input_text = input_text[:-1]
            elif e.key == pg.K_RETURN:
                if input_text.strip():
                    chat.append(('Ты', input_text))
                    # don't pass voice/flags explicitly so speech module falls back to shared settings
                    speak_async_chunked(input_text)
                    input_text = ''
                    scroll_offset = 0
            elif e.key == pg.K_v and mods & pg.KMOD_CTRL:
                input_text += pyperclip.paste()
            elif e.key == pg.K_F2:
                config.voice_index = (config.voice_index + 1) % len(config.voices_list)
            elif e.key == pg.K_F3:
                config.use_offline = not config.use_offline
            # Ctrl+Space -> toggle pause/resume
            elif (mods & pg.KMOD_CTRL) and e.key == pg.K_SPACE:
                if playback_ctrl.has_content():
                    playback_ctrl.toggle_pause()
            # Ctrl+M -> mute/unmute
            elif (mods & pg.KMOD_CTRL) and e.key == pg.K_m:
                playback_ctrl.toggle_mute()
            # Ctrl+R -> toggle repeat mode
            elif (mods & pg.KMOD_CTRL) and e.key == pg.K_r:
                playback_ctrl.toggle_repeat()
            # Ctrl+Del -> clear chat history
            elif (mods & pg.KMOD_CTRL) and e.key == pg.K_DELETE:
                chat.clear()
            elif e.key == pg.K_PAGEUP:
                scrolling_up = True
            elif e.key == pg.K_PAGEDOWN:
                scrolling_down = True
            elif e.key == pg.K_F9:
                dark_mode = not dark_mode
            elif (mods & pg.KMOD_CTRL) and (e.key in (pg.K_PLUS, pg.K_EQUALS, pg.K_KP_PLUS)):
                new_vol = min(MAX_VOLUME, playback_ctrl.get_volume_percent() + VOLUME_STEP)
                playback_ctrl.set_volume(new_vol)
                config.speech_volume = new_vol
            elif (mods & pg.KMOD_CTRL) and (e.key in (pg.K_MINUS, pg.K_KP_MINUS)):
                new_vol = max(MIN_VOLUME, playback_ctrl.get_volume_percent() - VOLUME_STEP)
                playback_ctrl.set_volume(new_vol)
                config.speech_volume = new_vol
            else:
                if len(input_text) < config.MAX_INPUT_LEN:
                    input_text += e.unicode
        elif e.type == pg.KEYUP:
            if e.key == pg.K_PAGEUP:
                scrolling_up = False
            elif e.key == pg.K_PAGEDOWN:
                scrolling_down = False


    # авто-прокрутка при удержании
    if scrolling_up:
        scroll_offset = min(scroll_offset + scroll_speed, 20)
    if scrolling_down:
        scroll_offset = max(scroll_offset - scroll_speed, 0)

    # render once and capture interactive targets for this frame
    last_targets = render_ui(screen, WIDTH, HEIGHT, font, chat, input_text, scroll_offset,
                             current_speed, dark_mode, show_settings, music_paused) or {}
    pg.display.flip()
    clock.tick(60)

# shut down playback thread cleanly
playback_ctrl._cmd_queue.put(('quit', None))
pg.quit()
