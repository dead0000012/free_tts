import pygame as pg
import threading
import queue
import collections
import threading
import os
import time
from settings import config

class PlaybackController:
    def __init__(self):
        self._cmd_queue = queue.Queue()
        self._lock = threading.Lock()
        self._is_paused = False
        self._is_playing = False
        self._running = True
        self._queue = collections.deque()  # pending file queue
        # volume stored as percent (-100..100)
        self._volume_percent = getattr(config, 'speech_volume', 0)
        self._thread = threading.Thread(target=self._worker, daemon=True)
        # current playback info (protected by _lock)
        self._current_file = None
        self._current_start = 0.0
        self._current_duration = None
        self._thread.start()

    def _ensure_mixer(self):
        try:
            if not pg.mixer.get_init():
                pg.mixer.init()
        except Exception:
            print("Warning: pygame.mixer unavailable; playback control disabled")
        # apply stored volume to mixer
        try:
            pg.mixer.music.set_volume(self._percent_to_mixer(self._volume_percent))
        except Exception:
            pass

    def _percent_to_mixer(self, percent):
        # map -100..100 -> 0.0..1.0
        try:
            p = max(-100, min(100, int(percent)))
        except Exception:
            p = 0
        return max(0.0, min(1.0, (p + 100) / 200.0))

    def set_volume(self, percent):
        with self._lock:
            self._volume_percent = max(-100, min(100, int(percent)))
            # apply to mixer only if not muted
            apply_vol = not getattr(self, '_is_muted', False)
        try:
            if apply_vol:
                pg.mixer.music.set_volume(self._percent_to_mixer(self._volume_percent))
        except Exception:
            pass

    def get_volume_percent(self):
        with self._lock:
            return self._volume_percent

    def _worker(self):
        self._ensure_mixer()
        current_file = None
        while self._running:
            # process control commands
            try:
                cmd, payload = self._cmd_queue.get(timeout=0.1)
            except queue.Empty:
                cmd = None
                payload = None

            if cmd == 'pause':
                try:
                    pg.mixer.music.pause()
                except Exception as e:
                    print('Playback error (pause):', e)
                with self._lock:
                    self._is_paused = True
                self._cmd_queue.task_done()
                continue
            elif cmd == 'unpause':
                try:
                    pg.mixer.music.unpause()
                except Exception as e:
                    print('Playback error (unpause):', e)
                with self._lock:
                    self._is_paused = False
                self._cmd_queue.task_done()
                continue
            elif cmd == 'stop':
                try:
                    pg.mixer.music.stop()
                except Exception as e:
                    print('Playback error (stop):', e)
                # clear queue and remove current file if any
                with self._lock:
                    self._is_paused = False
                    self._is_playing = False
                    self._queue.clear()
                # attempt to remove current file
                if current_file and os.path.exists(current_file):
                    try:
                        os.remove(current_file)
                    except Exception:
                        pass
                    current_file = None
                self._cmd_queue.task_done()
                continue
            elif cmd == 'quit':
                self._running = False
                self._cmd_queue.task_done()
                break
            elif cmd is not None:
                # wake/noop
                self._cmd_queue.task_done()

            # start next file if available and not paused and not already playing
            with self._lock:
                can_start = (not self._is_paused) and (not self._is_playing) and (len(self._queue) > 0)
            if can_start:
                try:
                    filepath = self._queue.popleft()
                except IndexError:
                    filepath = None
                if filepath:
                    current_file = filepath
                    try:
                        pg.mixer.music.load(filepath)
                        pg.mixer.music.play()
                        with self._lock:
                            self._is_playing = True
                            self._is_paused = False
                            # set current playback metadata
                            self._current_file = filepath
                            self._current_start = time.time()
                            try:
                                # try to get duration via Sound (works for many formats)
                                sound = pg.mixer.Sound(filepath)
                                self._current_duration = float(sound.get_length())
                                del sound
                            except Exception:
                                self._current_duration = None
                    except Exception as e:
                        print('Playback error (play):', e)
                        with self._lock:
                            self._is_playing = False
                            self._is_paused = False
                        # remove file if it's a temp
                        try:
                            if os.path.exists(filepath):
                                os.remove(filepath)
                        except Exception:
                            pass
                        current_file = None
                        with self._lock:
                            self._current_file = None
                            self._current_start = 0.0
                            self._current_duration = None
                        continue

            # monitor playback end: if playing but mixer no longer busy and not paused -> finished
            with self._lock:
                playing = self._is_playing
                paused = self._is_paused
            try:
                busy = pg.mixer.music.get_busy()
            except Exception:
                busy = False
            if playing and (not busy) and (not paused):
                # finished naturally
                # remove the file that was just played
                # if repeat mode is active -> requeue the same file and keep it
                with self._lock:
                    repeat_mode = getattr(self, '_repeat', False)
                if repeat_mode:
                    try:
                        # re-add the file to the left so it plays immediately again
                        self._queue.appendleft(current_file)
                    except Exception:
                        pass
                    # keep current_file (it will be set again when started)
                else:
                    if current_file and os.path.exists(current_file):
                        try:
                            os.remove(current_file)
                        except Exception:
                            pass
                current_file = None
                with self._lock:
                    self._is_playing = False
                    self._is_paused = False
                    self._is_setting = False
                    # clear current playback metadata (unless repeating; but safe to clear)
                    self._current_file = None
                    self._current_start = 0.0
                    self._current_duration = None
                # loop continues and will start next if queue not empty

        # on exit make sure mixer is stopped
        try:
            pg.mixer.music.stop()
        except Exception:
            pass

    def play(self, filepath=None):
        # add file to queue; do not start if paused.
        if filepath is None:
            return
        self._queue.append(filepath)
        # put a wake command so worker will re-check queue
        self._cmd_queue.put(('wake', None))

    def get_playback_progress(self):
        """Return (elapsed_seconds, duration_seconds_or_None). If nothing playing, returns (0.0, None)."""
        with self._lock:
            if not self._current_file or not self._is_playing:
                return 0.0, None
            duration = self._current_duration
        # try to get elapsed from mixer position (ms)
        try:
            pos_ms = pg.mixer.music.get_pos()
            if pos_ms is not None and pos_ms >= 0:
                elapsed = pos_ms / 1000.0
            else:
                elapsed = time.time() - self._current_start
        except Exception:
            elapsed = time.time() - self._current_start
        return elapsed, duration

    def pause(self):
        self._cmd_queue.put(('pause', None))

    def unpause(self):
        self._cmd_queue.put(('unpause', None))

    def stop(self):
        self._cmd_queue.put(('stop', None))

    def toggle_pause(self):
        with self._lock:
            if self._is_paused:
                self.unpause()
            else:
                # only allow pause if something is playing
                if self._is_playing:
                    self.pause()

    def resume_or_start(self):
        """If paused -> unpause. Else if not playing and queue has items -> kick worker to start next."""
        with self._lock:
            if self._is_paused:
                self.unpause()
                return
            has = len(self._queue) > 0
            is_playing = self._is_playing
        if (not is_playing) and has:
            # wake the worker to start next file
            self._cmd_queue.put(('wake', None))

    # new control helpers
    def mute(self):
        with self._lock:
            self._is_muted = True
        try:
            pg.mixer.music.set_volume(0.0)
        except Exception:
            pass

    def unmute(self):
        with self._lock:
            self._is_muted = False
            vol = self._percent_to_mixer(self._volume_percent)
        try:
            pg.mixer.music.set_volume(vol)
        except Exception:
            pass

    def toggle_mute(self):
        if getattr(self, '_is_muted', False):
            self.unmute()
        else:
            self.mute()

    def toggle_repeat(self):
        with self._lock:
            self._repeat = not getattr(self, '_repeat', False)

    def clear_history(self):
        """Clear the playback queue and stop current playback."""
        self.stop()

    def start(self):
        """Alias to wake worker to check queue/start playback."""
        self._cmd_queue.put(('wake', None))

    def is_paused(self):
        with self._lock:
            return self._is_paused

    def is_playing(self):
        with self._lock:
            return self._is_playing

    def has_content(self):
        # returns True if there is either something playing or pending in queue
        with self._lock:
            return self._is_playing or len(self._queue) > 0
    def settig(self):
        with self._lock:
            return self._is_setting
        
    def escape_setting(self):
        with self._lock:
            self._is_setting = False
            return self._is_setting
# create a single global instance to import
playback_ctrl = PlaybackController()
