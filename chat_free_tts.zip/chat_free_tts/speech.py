import threading
import asyncio
from chat_utils import split_text
from edge_tts import Communicate
from settings import config
import pyttsx3
import tempfile
import os
import pygame as pg
from playback_controller import playback_ctrl

engine = pyttsx3.init()


def _is_cyrillic(ch: str) -> bool:
    if not ch:
        return False
    o = ord(ch)
    # Cyrillic block ranges (basic Cyrillic and Cyrillic Supplement)
    return (0x0400 <= o <= 0x04FF) or (0x0500 <= o <= 0x052F)


def _pick_online_voice_index_by_lang(lang: str):
    """Return index in config.voices_list best matching lang ('ru' or 'en'), or None."""
    lang = (lang or '').lower()
    for i, v in enumerate(getattr(config, 'voices_list', [])):
        vid = str(v[0]).lower()
        if lang == 'ru' and vid.startswith('ru'):
            return i
        if lang == 'en' and vid.startswith('en'):
            return i
    return None


def _pick_offline_voice_id_by_lang(lang: str):
    """Try to find a pyttsx3 voice id that matches requested language.
    Returns voice.id or None.
    """
    try:
        voices = engine.getProperty('voices') or []
        lang = (lang or '').lower()
        # prefer exact matches in id/name
        for v in voices:
            name = (getattr(v, 'name', '') or '').lower()
            vid = (getattr(v, 'id', '') or '').lower()
            if lang == 'ru' and ('russian' in name or 'ru_' in vid or vid.startswith('ru')):
                return getattr(v, 'id', None)
            if lang == 'en' and ('english' in name or 'en_' in vid or vid.startswith('en')):
                return getattr(v, 'id', None)
        # fallback: return first voice that mentions the language token
        for v in voices:
            name = (getattr(v, 'name', '') or '').lower()
            vid = (getattr(v, 'id', '') or '').lower()
            if lang in name or lang in vid:
                return getattr(v, 'id', None)
    except Exception:
        pass
    return None

def speak_offline_to_file(text, rate=200, volume=1.0):
    # save offline TTS to a temporary WAV file and return its path
    fd, path = tempfile.mkstemp(suffix='.wav')
    os.close(fd)
    try:
        engine.setProperty('rate', rate)
        engine.setProperty('volume', max(0.0, min(1.0, volume)))
        engine.save_to_file(text, path)
        engine.runAndWait()
        # wait a short moment to ensure the file is flushed to disk
        try:
            import time as _t
            _t.sleep(0.005)
        except Exception:
            pass
        # validate file exists and has reasonable size
        try:
            if os.path.exists(path) and os.path.getsize(path) > 1000:
                return path
            else:
                # treat as failure
                try:
                    os.remove(path)
                except Exception:
                    pass
                return None
        except Exception:
            return None
    except Exception as e:
        try:
            os.remove(path)
        except Exception:
            pass
        print('Offline TTS error:', e)
        return None

def speak_async_chunked(text, voice_index=None, use_offline=None, speed=None, volume=None):
    """Озвучка с разбивкой длинного текста. Генерируем файлы и кладём их в очередь PlaybackController."""
    def _speak():
        chunks = split_text(text)
        # fallback to shared settings when caller didn't provide values
        offline = use_offline if use_offline is not None else config.use_offline

        for chunk in chunks:
            # read speed/volume dynamically per-chunk so UI changes take effect
            spd = speed if speed is not None else config.speech_speed
            volp = volume if volume is not None else config.speech_volume

            # language detection: inspect 1st and 3rd character (if present)
            s = chunk.strip()
            ch1 = s[0] if len(s) >= 1 else ''
            ch3 = s[2] if len(s) >= 3 else ''
            use_ru = _is_cyrillic(ch1) and _is_cyrillic(ch3)
            # pick online/offline voices according to detected language
            if use_ru:
                preferred_lang = 'ru'
            else:
                preferred_lang = 'en'

            if offline:
                # map speed (%) to rate: base ~200
                rate = 200 + int(spd)
                # map -100..100 -> 0.0..1.0 (0 -> 0.5 neutral)
                vol = (max(-100, min(100, volp)) + 100) / 200.0
                # try to pick an offline voice matching language
                voice_id = _pick_offline_voice_id_by_lang(preferred_lang)
                if voice_id:
                    try:
                        engine.setProperty('voice', voice_id)
                    except Exception:
                        pass
                temp_file = speak_offline_to_file(chunk, rate=rate, volume=vol)
                if temp_file:
                    playback_ctrl.play(temp_file)
                else:
                    # fallback: speak directly via pyttsx3 in this background thread
                    try:
                        # if playback controller is muted, skip direct speaking
                        if getattr(playback_ctrl, '_is_muted', False):
                            # nothing to do while muted
                            continue
                        engine.setProperty('rate', rate)
                        engine.setProperty('volume', max(0.0, min(1.0, vol)))
                        engine.say(chunk)
                        engine.runAndWait()
                    except Exception as e:
                        print('Offline direct speak failed:', e)
            else:
                try:
                    # pick an online voice index matching detected language if possible
                    vi_local = voice_index if voice_index is not None else config.voice_index
                    pick = _pick_online_voice_index_by_lang(preferred_lang)
                    if pick is not None:
                        vi_local = pick

                    voice = config.voices_list[vi_local][0]
                    # edge_tts expects strings like '+20%' or '-10%'
                    rate = f"{ '+' if spd >= 0 else '' }{int(spd)}%"
                    vol = f"{ '+' if volp >= 0 else '' }{int(volp)}%"
                    # create temp file
                    fd, temp_file = tempfile.mkstemp(suffix='.mp3')
                    os.close(fd)
                    # run the async save synchronously
                    try:
                        asyncio.run(Communicate(text=chunk, voice=voice, rate=rate, volume=vol).save(temp_file))
                        playback_ctrl.play(temp_file)
                    except Exception as e:
                        try:
                            os.remove(temp_file)
                        except Exception:
                            pass
                        print('Ошибка онлайн озвучки:', e)
                except Exception as e:
                    print('Ошибка подготовки онлайн озвучки:', e)
    threading.Thread(target=_speak, daemon=True).start()
